#Leonardo Vieira: 82094 - Duarte Faria: 79856 - Grupo: T037
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 15:51:49 2018

@author: mlopes
"""
import numpy as np
from copy import deepcopy
import copy as copy


class Node():
    def __init__(self, prob, parents = []):
        self.prob = prob
        self.parents = parents
    
    def computeProb(self, evid):
        self.evid = evid
        n=len(self.prob)
        a=self.prob
        if n>=2:
            for i in self.parents:
                a=a[evid[i]]
        else:
            a=a[0]
        return [1-a,a]
    
class BN():
    def __init__(self, gra, prob):
        self.gra=gra
        self.prob=prob
        
    def computePostProbEvidAux(self, evidList, pos):
        
        temp=[]
        flag=0
        for i in range(0,len(evidList)):
            if (i==len(evidList)/2):
                flag=1
                
            evidList[i][pos]=flag
            temp.append(copy.deepcopy(evidList[i]))
            
        
        return temp
        

    def computePostProb(self, evid):
        evidList=[list(evid)]
        res=0
        pos=0
        pos2=[]
        pos3=-1

        for evi in evid:
            if (evi==[]):
                pos2.append(pos)
            elif (evi==-1):
                pos3=pos
                
            pos=pos+1
            
        for p in pos2:
            evidList=(self.computePostProbEvidAux(evidList.copy()+evidList.copy(),p))
        
        j=0
        soma=1
        alpha=0
        menosUm=0      
        for ev in evidList:
            j=0
            for n in self.prob:
                if (j!=pos3):
                    
                    ev[pos3]=1
                    p=n.computeProb(tuple(ev))[ev[j]]
                    if (j==pos2[0]):
                        
                        alpha=1/n.computeProb(tuple(ev))[1]
                    soma=soma*p
                else:
                    menosUm=n.computeProb(tuple(ev))[1]
                j=j+1

            res=res+soma
            soma=1
           
        return res*menosUm*alpha
        
        
    def computeJointProb(self, evid):
        m=1
        p=0
        for n in self.prob:
            m=m*n.computeProb(evid)[evid[p]]
            p=p+1
        
        return m
