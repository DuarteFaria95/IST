//Duarte Faria		79856
//Francisco Sousa	82037	
//Ricardo Almeida	77994

#include <stdlib.h>
#include <stdio.h>
#include "commandlinereader.h"
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include "list.h"
#include <semaphore.h>

#define MAXARG 7
#define MAXPAR 2
#define BUFFER_SIZE  100

/**** VARIAVEIS GLOBAIS ***/
int pid, status = 0;
pthread_t tid[1];
list_t *list;
int flag = 0;
int num_children = 0;
pthread_mutex_t data_ctrl;
pthread_cond_t nochild,maxchild;
int id = -1;
int id_ini = -1;
FILE * logt;

/***************************/

/*** VERIFICAÇOES ***/

void mutex_lock(void) {
  if(pthread_mutex_lock(&data_ctrl) != 0)
  {
    fprintf(stderr, "Error in pthread_mutex_lock()\n");
    exit(EXIT_FAILURE);
  }
}

void mutex_unlock(void) {
  if(pthread_mutex_unlock(&data_ctrl) != 0)
  {
    fprintf(stderr, "Error in pthread_mutex_unlock()\n");
    exit(EXIT_FAILURE);
  }
}


/*****************************************************************************
* FUNCAO SAIR ****************************************************************
******************************************************************************/
int sair(){ 
	pthread_join(tid[0],NULL);
	lst_print(list,logt,id_ini);
	pthread_mutex_destroy(&data_ctrl);
	pthread_cond_destroy(&maxchild);
	pthread_cond_destroy(&nochild);
	fclose(logt);
	exit(EXIT_SUCCESS); 
}
/******************************************************************************
 FUNCAO MONITORA **************************************************************
******************************************************************************/
void *monitora(void *x){

	while(1){
		
		/* Variavel de condiçao: espera por childs*/
		mutex_lock();
		while (num_children == 0 && flag == 0) pthread_cond_wait(&nochild,&data_ctrl);
		mutex_unlock();

		/*Verificaçao do comando exit*/
		mutex_lock();
		if(flag == 1 && num_children == 0){
			pthread_exit(NULL);
			mutex_unlock();
		}
		mutex_unlock();


		pid=wait(&status);
		mutex_lock();
		update_terminated_process(list, pid, time(NULL));
		//lst_print(list,logt,pid);
		num_children--;
		mutex_unlock();
		mutex_lock();
		pthread_cond_signal(&maxchild);
		mutex_unlock();
		
		
			
	}
	mutex_unlock();
}
/******************************************************************************
 FUNCAO MAIN **************************************************************
******************************************************************************/

int main(int num_max,char const *argv[])
{
 	char *command[MAXARG];
	list = lst_new();
	char buffer[BUFFER_SIZE];
	

	/*criar mutex*/
	pthread_mutex_init(&data_ctrl, NULL);
	/* criar thread*/
	pthread_create(&tid[0],NULL,monitora,NULL);
	logt=fopen("log.txt","a+");
	int nrlinha = 0;
	char ch;

	while((ch = fgetc(logt)) != EOF){
		if (ch == '\n')
		nrlinha++;

	}
	id = (nrlinha/3)-1;
	id_ini = id;
	
	while(1){

		while(readLineArguments(command,MAXARG,buffer, BUFFER_SIZE)==0);// caso o utilizador nao escreva nada, continua a pedir
		
		/* received the exit command*/
		if (strcmp(command[0],"exit")== 0 ){	
			mutex_lock();
			flag = 1;
			pthread_cond_signal(&nochild);	
			mutex_unlock();
			sair();	
		}

		else{
			
			mutex_lock();
			while (num_children >= MAXPAR) pthread_cond_wait(&maxchild,&data_ctrl);
			mutex_unlock();
			pid = fork();
			
			if (pid < 0){
				fputs("Erro na execucao do comando\n",stderr);
				continue;
			}
			if (pid==0){
				execv(command[0],command);	
				fputs("Comando Invalido\n",stderr); // se nao conseguir executar o processo			
  				exit(EXIT_FAILURE);
			}
			else{
				mutex_lock();
				num_children++;
				id++;
				mutex_unlock();
				mutex_lock();
				pthread_cond_signal(&nochild);
				insert_new_process(list, pid, time(NULL),id);
				mutex_unlock();
			}
			}
		}		
	}

