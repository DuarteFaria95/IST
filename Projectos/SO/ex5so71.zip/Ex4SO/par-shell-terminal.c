#include <stdlib.h>
#include <stdio.h>
#include "commandlinereader.h"
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include "list.h"
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#define MAXARG 7
#define BUFFER_SIZE 100

char buffer[BUFFER_SIZE];
char new_comm[BUFFER_SIZE];
int fd;
int sd;
char pid_pipe[BUFFER_SIZE];
int num_chilld = 0;
int tempo_exec = 0;

char texto[BUFFER_SIZE];

int main(int argc, char **argv)
{
	/*Abrir o pipe para escrever*/
	fd = open(argv[1], O_WRONLY);
	dup2(fd, 1);
	char new[BUFFER_SIZE];
	
	sprintf(new,"novo %d\n",getpid());

	write(fd,new,strlen(new));

	while(1){
		/*escrever no buffer o comando do  utilizador*/
			if(fgets(buffer, BUFFER_SIZE, stdin) == NULL) {
    			return -1;}
			
    		if (strcmp(buffer,"exit-global\n")== 0 ){	
    			write(fd,"exit\n",strlen("exit\n"));
				exit(EXIT_SUCCESS);	
			}
    		if (strcmp(buffer,"exit\n")== 0 ){
    			sprintf(new,"stop %d\n",getpid());
    			write(fd,new,strlen(new));
				exit(EXIT_SUCCESS);
			}
			else if (strcmp(buffer,"stats\n")== 0 ){	
				sprintf(pid_pipe,"/tmp/par-shell-%d",getpid());
				sprintf(new_comm,"stats ");
				strcat(new_comm,pid_pipe);
				strcat(new_comm,"\n");
				
				if (mkfifo(pid_pipe, 0777) < 0){
					printf("pipe ja existe");
					exit (-1);}

				write(fd,new_comm,strlen(new_comm));
				sd = open(pid_pipe, O_RDONLY);
				read(sd,texto,BUFFER_SIZE);
				fputs(texto,stderr);
				close(sd);
				unlink(pid_pipe);
			} 	
			/*escrever no pipe*/	
			else{
    			write(fd, buffer, strlen(buffer)); 
    			
    		}	 	
	}
	return 0;
}