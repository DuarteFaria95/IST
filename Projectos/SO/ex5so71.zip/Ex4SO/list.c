/*
 * list.c - implementation of the integer list functions 
 */


#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <signal.h> 
#include "list.h"

#define BUFFER_SIZE  100

list_t* lst_new()
{
   list_t *list;
   list = (list_t*) malloc(sizeof(list_t));

   list->first = NULL;
   return list;
}


void lst_destroy(list_t *list)
{
	struct lst_iitem *item, *nextitem;

	item = list->first;
	while (item != NULL){
		nextitem = item->next;
		free(item);
		item = nextitem;
	}
	free(list);
}



void insert_new_process(list_t *list, int pid, time_t starttime, int id)
{
	lst_iitem_t *item;
	item = (lst_iitem_t *) malloc (sizeof(lst_iitem_t));
	item->pid = pid;
	item->id = id;
	item->starttime = starttime;
	item->endtime = 0;
	item->finaltime = 0;
	item->next = list->first;
	list->first = item;
}

void insert_new_terminal(list_t *list, int pid, int t)
{
	lst_iitem_terminal *item;
	item = (lst_iitem_t *) malloc (sizeof(lst_iitem_terminal));
	item->pid = pid;
	item->aberto = t;
	item->next = list->first;
	list->first = item;
}

void update_terminal(list_t *list, int pid)
{

lst_iitem_terminal *item;

item = list->first;

while(item != NULL){
	if(item->pid == pid){
  		item->aberto = 0;
	}
	item = item->next;
}

}

void kill_terminal(list_t *list)
{
  lst_iitem_terminal *item;

  item = list->first;


  while (item != NULL){
  	if (item->aberto==1){
      kill(item->pid, SIGKILL);
    }
    item = item->next;
  }
}

//--------------------------------------------------------------------------------------

void update_terminated_process(list_t *list, int pid, time_t endtime)
{

lst_iitem_t *item;

item = list->first;

while(item != NULL){
	if(item->pid == pid){
  		item->endtime = endtime;
  		item->finaltime = (int)(item->endtime - item->starttime);
	}
	item = item->next;
}

}

int rt_finaltime(list_t *list,int pid){
	lst_iitem_t *item;
	item = list->first;

	while(item != NULL){
		if(item->pid == pid){
	  		return item->finaltime;
		}
		item = item->next;
	}
}

void reverse(list_t *list){
	lst_iitem_t *current=list->first, *prev =NULL, *next;
	while(current!=NULL){
		next = current->next;
		current->next = prev;
		prev = current;
		current = next;
	}
	list->first = prev;

}

int lastline(FILE * f){

	char buff[BUFFER_SIZE + 1];
	char *last_newline;
	char *last_line;

	if(f != NULL){
		fseek(f,-BUFFER_SIZE,SEEK_END);
		fread(buff,BUFFER_SIZE-1,1,f);
		buff[BUFFER_SIZE - 1]= '\0';
		last_newline = strrchr(buff, '\n');
		last_line = last_newline+1;
		char num[10];
		int i = 22;
		while (last_line[i] != 's'){
			num[i-22]=last_line[i];
			i++;
		}
		return atoi(num);
		
		
	}
	return 0;
}

//--------------------------------------------------------------------------------------

void lst_print(list_t *list,FILE * f,int id)
{
	int temp_total = 0;
	if (id != -1)
		temp_total = lastline(f);
	
	lst_iitem_t *item;
	
	reverse(list);

	item = list->first;
	
	while (item != NULL){
		temp_total += item->finaltime;
		fprintf(f,"iteracao %d\npid: %d execution time: %d s\ntotal execution time: %d s\n",item->id,item->pid,(int)(item->endtime - item->starttime),temp_total);
		item = item->next;
	}
}

