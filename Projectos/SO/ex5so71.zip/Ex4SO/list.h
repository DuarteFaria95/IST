/*
 * list.h - definitions and declarations of the integer list 
 */


#include <stdlib.h>
#include <stdio.h>
#include <time.h>


#define BUFFER_SIZE  100

/* lst_iitem - each element of the list points to the next element */
typedef struct lst_iitem {
   int pid;
   int id;
   time_t starttime;
   time_t endtime;
   int finaltime;
   struct lst_iitem *next;
} lst_iitem_t;

typedef struct lst_iitem_term {
   int pid;
   int aberto;
   struct lst_iitem *next;
} lst_iitem_terminal;



// lask - lista do gestor de tarefas pessoais
typedef struct task{
	int pid;
	int id;
	struct task *next;
}task;

	


/* list_t */
typedef struct {
   lst_iitem_t * first;
} list_t;

typedef struct{
	
	task * first;
}task_list;






/* lst_new - allocates memory for list_t and initializes it */
list_t* lst_new();

/* lst_destroy - free memory of list_t and all its items */
void lst_destroy(list_t *);

/* insert_new_process - insert a new item with process id and its start time in list 'list' */
void insert_new_process(list_t *list, int pid, time_t starttime,int id);


void insert_new_terminal(list_t *list, int pid, int t);


void update_terminal(list_t *list, int pid);


void kill_terminal(list_t *list);

/* lst_remove - remove first item of value 'value' from list 'list' */
void update_terminated_process(list_t *list, int pid, time_t endtime);

int rt_finaltime(list_t *list,int pid);

int lastline(FILE * f);

void reverse(list_t *list);
/* lst_print - print the content of list 'list' to standard output */
void lst_print(list_t *list,FILE * f,int id);
