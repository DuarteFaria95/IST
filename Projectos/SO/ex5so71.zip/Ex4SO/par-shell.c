//Duarte Faria		79856
//Francisco Sousa	82037	
//Ricardo Almeida	77994

#include <stdlib.h>
#include <stdio.h>
#include "commandlinereader.h"
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include "list.h"
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h> 


#define MAXARG 7
#define MAXPAR 2
#define BUFFER_SIZE  100

/**** VARIAVEIS GLOBAIS ***/
int pid, status = 0;
pthread_t tid[1];
list_t *list;
list_t *lst_terminal;
int flag = 0;
int num_children = 0;
pthread_mutex_t data_ctrl;
pthread_cond_t nochild,maxchild;
int id = -1;
int id_ini = -1;
FILE * logt;
char PID_file[80];
int p;
char *mypipe = "/tmp/par-shell-in";
char *statpipe;
int fd;
int sd;
int tempo_exec = 0;
char texto[BUFFER_SIZE];
int terminais = 0;
/***************************/


/*** VERIFICAÇOES ***/

void mutex_lock(void) {
  if(pthread_mutex_lock(&data_ctrl) != 0)
  {
    fprintf(stderr, "Error in pthread_mutex_lock()\n");
    exit(EXIT_FAILURE);
  }
}

void mutex_unlock(void) {
  if(pthread_mutex_unlock(&data_ctrl) != 0)
  {
    fprintf(stderr, "Error in pthread_mutex_unlock()\n");
    exit(EXIT_FAILURE);
  }
}

void SIG_Hand(int sig) {
		dup2(fd, 1);
		kill_terminal(lst_terminal);
		unlink(mypipe);
		exit(EXIT_FAILURE);
	}

/*****************************************************************************
* FUNCAO SAIR ****************************************************************
******************************************************************************/
int sair(){ 
	pthread_join(tid[0],NULL);
	lst_print(list,logt,id_ini);
	pthread_mutex_destroy(&data_ctrl);
	pthread_cond_destroy(&maxchild);
	pthread_cond_destroy(&nochild);

	kill_terminal(lst_terminal);

	close(fd);
	fclose(logt);
	unlink(mypipe);
	exit(EXIT_SUCCESS); 
}

/******************************************************************************
 FUNCAO MONITORA **************************************************************
******************************************************************************/
void *monitora(void *x){
	while(1){
		/* Variavel de condiçao: espera por childs*/
		mutex_lock();
		while (num_children == 0 && flag == 0) pthread_cond_wait(&nochild,&data_ctrl);
		mutex_unlock();

		/*Verificaçao do comando exit*/
		mutex_lock();
		if(flag == 1 && num_children == 0){
			pthread_exit(NULL);
			mutex_unlock();
		}
		mutex_unlock();

		pid=wait(&status);
		mutex_lock();
		update_terminated_process(list, pid, time(NULL));
		tempo_exec += rt_finaltime(list,pid);
		num_children--;
		mutex_unlock();
		mutex_lock();
		pthread_cond_signal(&maxchild);
		mutex_unlock();		
	}
	mutex_unlock();
}
/******************************************************************************
 FUNCAO MAIN **************************************************************
******************************************************************************/
int main(int num_max,char const *argv[])
{
 	char *command[MAXARG];
	list = lst_new();
	lst_terminal =lst_new();
	char buffer[BUFFER_SIZE];
	unlink(mypipe);
	/*criar mutex*/
	pthread_mutex_init(&data_ctrl, NULL);
	/* criar thread*/
	pthread_create(&tid[0],NULL,monitora,NULL);
	logt=fopen("log.txt","a+");
	int nrlinha = 0;
	char ch;
	signal(SIGINT, SIG_Hand);


	
	if (mkfifo(mypipe, 0666) < 0){
		printf("pipe ja existe");
		exit (-1);}

	fd = open(mypipe, O_RDONLY);
	dup2(fd, 0);
	
	while((ch = fgetc(logt)) != EOF){
		if (ch == '\n')
		nrlinha++;
	}
	id = (nrlinha/3)-1;
	id_ini = id;
	
	while(1){

    	while(readLineArguments(command,MAXARG,buffer, BUFFER_SIZE)==0);

    	if (strcmp(command[0],"novo")== 0){
    		terminais++;
    		insert_new_terminal(lst_terminal,atoi(command[1]),1);


    	}
		/* received the exit command*/
		else if (strcmp(command[0],"exit")== 0 ){	
				mutex_lock();
				flag = 1;
				pthread_cond_signal(&nochild);	
				mutex_unlock();
				sair();	
		}
		/* received the stats command*/	
		else if (strcmp(command[0],"stats")== 0){
			
			char tempinho[BUFFER_SIZE];
			sprintf(texto,"Numero de processos filho em exec: %d\n",num_children);
			sprintf(tempinho,"Tempo total: %d\n",tempo_exec);
			sd = open(command[1], O_WRONLY);
			strcat(texto,tempinho);;
			write(sd,texto, strlen(texto));
			close(sd);
		}
		else if (strcmp(command[0],"stop")== 0){
				terminais--;
				update_terminal(lst_terminal,command[1]);
				if (terminais == 0){
					dup2(fd, 1);
			}
		
		}

		else{
			mutex_lock();
			while (num_children >= MAXPAR) pthread_cond_wait(&maxchild,&data_ctrl);
			mutex_unlock();
			pid = fork();
			
			if (pid < 0){
				fputs("Erro na execucao do comando\n",stderr);
				continue;
			}
			if (pid==0){


				/*Criar o ficheiro de txt para o processo filho*/
				sprintf(PID_file,"/tmp/par-shell-out-%d.txt",getpid());
				p = open(PID_file,O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR);
				dup2(p,1);
				close(p);

				execv(command[0],command);					
				fputs("Comando Invalido\n",stderr); // se nao conseguir executar o processo			
  				exit(EXIT_FAILURE);
			}
			else{
				mutex_lock();
				num_children++;
				id++;
				pthread_cond_signal(&nochild);
				insert_new_process(list, pid, time(NULL),id);
				mutex_unlock();
			}
			}
		}		
	}

