//Duarte Faria		79856
//Francisco Sousa	82037	
//Ricardo Almeida	77994

#include <stdlib.h>
#include <stdio.h>
#include "commandlinereader.h"
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include "list.h"
#include <semaphore.h>

#define MAXARG 7
#define MAXPAR 2


int num_pross = 0;
int pid, status = 0;
pthread_t tid[1];
list_t *list;
int flag=0;
int num_children=0;
pthread_mutex_t data_ctrl;
sem_t semaforo1;
sem_t semaforo2;

void semaforo_wait(sem_t *sem){
	if(sem_wait(sem)!=0){
		fprintf(stderr, "Error in sem_wait\n");
		exit(EXIT_FAILURE);
	}
}

void semaforo_init(sem_t *sem,int a,int m){
	if(sem_init(sem,a,m)!=0){
		fprintf(stderr, "Error in sem_init\n" );
		exit(EXIT_FAILURE);
	}
}

void semaforo_post(sem_t *sem){
	if(sem_post(sem)!=0){
		fprintf(stderr, "Error in sem_post\n" );
		exit(EXIT_FAILURE);
	}
}


int sair(){ 
	pthread_join(tid[0],NULL);
	lst_print(list); 
	pthread_mutex_destroy(&data_ctrl);
	exit(EXIT_SUCCESS); 
}

void mutex_lock(void) {
  if(pthread_mutex_lock(&data_ctrl) != 0)
  {
    fprintf(stderr, "Error in pthread_mutex_lock()\n");
    exit(EXIT_FAILURE);
  }
}

void mutex_unlock(void) {
  if(pthread_mutex_unlock(&data_ctrl) != 0)
  {
    fprintf(stderr, "Error in pthread_mutex_unlock()\n");
    exit(EXIT_FAILURE);
  }
}

void *monitora(void *x){

	while(1){
		mutex_lock();
		if(num_children >0){
			mutex_unlock();
			pid=wait(&status);
			semaforo_post(&semaforo1);
			mutex_lock();
			num_children--;
			semaforo_wait(&semaforo2);
			update_terminated_process(list, pid, time(NULL));
			mutex_unlock();
		}
		else{
			if(flag == 1){
				mutex_unlock();
				pthread_exit(NULL);

//				
//				semaforo_wait(&semaforo2);
//				printf("olalaaa\n");
//				continue;
			}

						
		}

	mutex_unlock();
	}

}


int main(int num_max,char const *argv[])
{
 	char *command[MAXARG];
	list = lst_new();
	pthread_mutex_init(&data_ctrl, NULL);
	pthread_create(&tid[0],NULL,monitora,NULL);
	semaforo_init(&semaforo1,0,MAXPAR);
	semaforo_init(&semaforo2,0,0);

	while(1){

		while(readLineArguments(command,MAXARG)==0);// caso o utilizador nao escreva nada, continua a pedir
		
		if (strcmp(command[0],"exit")== 0 ){	
			mutex_lock();
			flag = 1;	
			mutex_unlock();
			sair();	
		}

		else{
			semaforo_wait(&semaforo1);
			pid = fork();
			
			num_pross++; // variavel que conta o numero de processos
			
			if (pid < 0){
				fputs("Erro na execucao do comando\n",stderr);
				continue;
			}
			if (pid==0){
				execv(command[0],command);	
				fputs("Comando Invalido\n",stderr); // se nao conseguir executar o processo			
  				exit(EXIT_FAILURE);
			}
			else{
				mutex_lock();
				num_children++;
				semaforo_post(&semaforo2);
				insert_new_process(list, pid, time(NULL));
				mutex_unlock();
			}
			}
		}		
	}

