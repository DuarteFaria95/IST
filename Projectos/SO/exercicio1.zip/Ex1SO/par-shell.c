//Duarte Faria		79856
//Francisco Sousa	82037	
//Ricardo Almeida	77994
//
#include <stdlib.h>
#include <stdio.h>
#include "commandlinereader.c"
#include <string.h>

#define MAXARG 7

int num_pross = 0;
int pid, status = 0;

int main()
{
	char *command[MAXARG];
	int i=0;

	while(1){
		while(readLineArguments(command,MAXARG)==0); // caso o utilizador nao escreva nada, continua a pedir
		if (strcmp(command[0],"exit")== 0){	
			sair();	
		}

		else{
			
			pid = fork();
			num_pross++; // variavel que conta o numero de processos
			if (pid < 0){
				fputs("Erro na execucao do comando\n",stderr);
				continue;
			}
			if (pid==0){
				execv(command[0],command);				
				fputs("Comando Invalido\n",stderr); // se nao conseguir executar o processo
				exit(EXIT_FAILURE);
			}
		}
	}
}

int sair(){ 
	int *vetor_r; //vector que guarda o valor retornado de cada processo filho
	int *vetor_p; //vector que guarda o pid de cada processo filho
	int i =0;
	int count=0;
	vetor_r = malloc(num_pross * (sizeof(int)));
	vetor_p = malloc(num_pross * (sizeof(int)));	
	for (i = 0; i < num_pross; i++)
	{
		pid= wait(&status);
		if(pid>0 && WIFEXITED(status)==1){
			vetor_r[i] = WEXITSTATUS(status);
			vetor_p[i] = pid;
			count++;
		}
	}
	for (i = 0; i < count; i++) { 
		printf("Pid --> %d Valor Retornado --> %d\n",vetor_p[i],vetor_r[i]);
	}
	free(vetor_p);
	free(vetor_r); 
	exit(EXIT_SUCCESS); 
}
