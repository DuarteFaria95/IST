//Duarte Faria		79856
//Francisco Sousa	82037	
//Ricardo Almeida	77994

#include <stdlib.h>
#include <stdio.h>
#include "commandlinereader.h"
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include "list.h"

#define MAXARG 7

int num_pross = 0;
int pid, status = 0;
pthread_t tid[1];
list_t *list;
int flag=0;
int num_children=0;
pthread_mutex_t trinco_lock;

int sair(){ 
	pthread_join(tid[0],NULL);
	lst_print(list); 
	pthread_mutex_destroy(&trinco_lock);
	exit(EXIT_SUCCESS); 
}

void *monitora(void *x){

	while(1){
		pthread_mutex_lock(&trinco_lock);
		if(num_children >0){
			pid=wait(&status);
			num_children--;
			update_terminated_process(list, pid, time(NULL));

		}
		else{
			if(flag == 0){
				sleep(1);

			}
			else{
				pthread_exit(NULL);
			}
		}
		pthread_mutex_unlock(&trinco_lock);

	}

}


int main(int num_max,char const *argv[])
{
 	char *command[MAXARG];
	list = lst_new();
	pthread_mutex_init(&trinco_lock, NULL);
	pthread_create(&tid[0],NULL,monitora,NULL);
	
	while(1){

		while(readLineArguments(command,MAXARG)==0);// caso o utilizador nao escreva nada, continua a pedir
		
		if (strcmp(command[0],"exit")== 0 ){	
			flag = 1;	
			sair();	
		}

		else{
		//	pthread_mutex_lock(&trinco_lock);
			pid = fork();
			
			num_pross++; // variavel que conta o numero de processos
			num_children++;
			if (pid < 0){
				fputs("Erro na execucao do comando\n",stderr);
				continue;
			}
			if (pid==0){
				execv(command[0],command);	
				fputs("Comando Invalido\n",stderr); // se nao conseguir executar o processo			
  				exit(EXIT_FAILURE);
			}
			else{
				insert_new_process(list, pid, time(NULL));
				
			}
			//pthread_mutex_unlock(&trinco_lock);
			}
		}		
	}

