<html>
    <body>
        <h3>Insira novo Local</h3>
        <form action="updatelocal.php" method="post">
            <p>Morada Local: <input type="text" name="moradalocal"/></p>
            <p><input type="submit" value="Inserir"/></p>
        </form>
    </body>
</html>