<html>
    <body>
        <h3>Insira Nova Entidade</h3>
        <form action="updateentidade.php" method="post">
            <p>Nome Entidade: <input type="text" name="nomeentidade"/></p>
            <p><input type="submit" value="Inserir"/></p>
        </form>
    </body>
</html>