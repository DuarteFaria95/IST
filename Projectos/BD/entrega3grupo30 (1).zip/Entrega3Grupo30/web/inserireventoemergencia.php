<html>
    <body>
        <h3>Insira Evento de Emergencia</h3>
        <form action="updateeventoemergencia.php" method="post">
            <p>Numero telefone: <input type="text" name="numtelefone"/></p>
            <p>Instante da chamada: <input type="text" name="instantechamada"/></p>
            <p>Nome Pessoa: <input type="text" name="nomepessoa"/></p>
            <p>Local: <input type="text" name="moradalocal"/></p>
            <p>Numero Processo Socorro: <input type="text" name="numprocessosocorro"/></p>
            <p><input type="submit" value="Inserir"/></p>
        </form>
    </body>
</html>