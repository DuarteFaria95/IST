#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <sys/stat.h> 
#include <netinet/in.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include "packet-format.h"
#include <unistd.h>
#include <stdbool.h>
#include <math.h>
#define MAXLINE 1024 
#define MAX_DATA_SIZE 100

// Driver code 
int main(int argc, char *argv[]){
 

    if( argc != 5 ) {
        printf("Invalid Arguments\n");
        exit(-1);
    }

    int sockfd; 
   // char buffer[MAXLINE]; 
    //char *hello = argv[1]; 
    struct sockaddr_in     servaddr; 

    struct hostent *hostEnt;
    

    if ((hostEnt=gethostbyname(argv[2])) == NULL) {  /* get the host info */
        printf("Host error");
        exit(-1);
    }
  
    // Creating socket file descriptor 
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
        perror("socket creation failed"); 
        exit(EXIT_FAILURE); 
    } 
   
    bzero(&servaddr, sizeof(servaddr));
    // Filling server information 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_port = htons(atoi(argv[3])); 
    servaddr.sin_addr = *((struct in_addr *)hostEnt->h_addr); 
    

    const char *inputFileName = argv[1];
    FILE *inputFile;

    inputFile = fopen(inputFileName, "rb");
    
    bool endOfFile = feof(inputFile);
    char nextChar;
    //calcular o n de chunks

    struct stat inputFileInfo;

    stat(inputFileName, &inputFileInfo);

    unsigned int total_frag = ((inputFileInfo.st_size) / MAX_DATA_SIZE) + 1;
   // unsigned int current_frag_no = 1;

    //enquanto o n de chunks for menor que o total
   
    struct data_pkt_t *chunk = malloc(sizeof (struct data_pkt_t)*total_frag);
    int *b = malloc(sizeof (int)*total_frag);
    struct  ack_pkt_t chunkACK;
    chunkACK.seq_num = htonl(1);
    chunkACK.selective_acks = 0;
    int n= 0;
    int len = sizeof(struct sockaddr_in);
    int window = 0;
    int fim = 0;

    // prepara os chunks

    for (int i = 0; i <= total_frag ;i++){
            b[i]=0;
            chunk[i].seq_num = htonl(i+1);
        
            for (int k = 0; k < MAX_DATA_SIZE && !endOfFile; k++) 
            {
                nextChar = getc(inputFile);
                if (feof(inputFile)) {
                    endOfFile = true;
                    
                    k--;
                } else {
                    chunk[i].data[k] = nextChar;
                }
            }
    }


    while(1){
        for (int i = 0; i < atoi(argv[4]) ;i++){

            //ver quais sao preciso enviar atravez do selective_acks
            if (b[ntohl(chunkACK.seq_num)+ i-1] == 0)
            {
                
                
                sendto(sockfd, (struct data_pkt_t *)&chunk[ntohl(chunkACK.seq_num)+ i-1], sizeof(chunk[ntohl(chunkACK.seq_num)+ i-1]) ,0, (const struct sockaddr *) &servaddr,sizeof(servaddr)); 
                
                printf("%d ---- %d\n", 1+window , window + atoi(argv[4]));
                printf("send : %d , len: %ld\n",ntohl(chunk[ntohl(chunkACK.seq_num)+ i-1].seq_num),strlen(chunk[ntohl(chunkACK.seq_num)+ i-1].data ));
                if (strlen(chunk[ntohl(chunkACK.seq_num)+ i-1].data )< MAX_DATA_SIZE)
                {
                    break;
                }
            }
        }

        for (int i = 1+window; i <= atoi(argv[4])+window;i++){

            n = recvfrom(sockfd, (struct ack_pkt_t *)&chunkACK,sizeof(chunkACK),0, (struct sockaddr *) &servaddr, (socklen_t *) &len); 
            printf("Acknowledge : %d : %d\n", ntohl(chunkACK.seq_num),n); 
            b[i-1]=1;
            if (ntohl(chunkACK.seq_num) == window +2)
            {
                window++;
                if (ntohl(chunkACK.seq_num)-1 == total_frag)
                {
                    fim = 1;
                }
                break;
            }
        }
        if (fim==1)
         {
             break;
         } 

    }
    
    close(sockfd); 
    return 0; 
} 