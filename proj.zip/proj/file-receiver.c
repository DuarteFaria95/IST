
// Server side implementation of UDP client-server model 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include "packet-format.h"

#define MAXLINE 1024 
#define MAX_DATA_SIZE 100
  
int main(int argc, char *argv[]){
    
    char text[10000] = "";

    if( argc != 4 ) {
        printf("Invalid Arguments\n");
        exit(-1);
    }

    int sockfd; 
   // char buffer[MAXLINE]; 
   // char *hello = argv[1]; 
    struct sockaddr_in servaddr, cliaddr; 
      
    // Creating socket file descriptor 
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
        perror("socket creation failed"); 
        exit(-1); 
    } 
      
    bzero(&servaddr, sizeof(servaddr)); 
    bzero(&cliaddr, sizeof(cliaddr));  
      
    // Filling server information 
    servaddr.sin_family    = AF_INET; // IPv4 
    servaddr.sin_addr.s_addr = INADDR_ANY; 
    servaddr.sin_port = htons(atoi(argv[2])); 
      
    // Bind the socket with the server address 
    if ( bind(sockfd, (const struct sockaddr *)&servaddr,  
            sizeof(servaddr)) < 0 ) 
    { 
        perror("bind failed"); 
        exit(EXIT_FAILURE); 
    } 
    
    char *str[100];    

    struct  data_pkt_t chunk;
    struct  ack_pkt_t chunkACK;
    chunkACK.seq_num = 1;
    chunkACK.selective_acks = 0;
    int  n;
    int len = sizeof(struct sockaddr_in);
    int window = 0;
    int fim = 0;
    int count = 0;
    while(1){

        for (int i = 1+window; i <= atoi(argv[3])+window;i++){
            bzero(&chunk, sizeof(struct data_pkt_t)); 
            n = recvfrom(sockfd, (struct data_pkt_t *)&chunk, sizeof(chunk) ,0, ( struct sockaddr *) &cliaddr, (socklen_t *) &len); 
            

            //printf("%d ---- %d\n", 1+window , window + atoi(argv[3]));
            printf("id: %d - len: %ld - size: %d\n", ntohl(chunk.seq_num),strlen(chunk.data),n); 
            
                
            if (ntohl(chunk.seq_num) == window+2)
            {
                window++;
                
            }
            
            chunkACK.seq_num =  htonl(ntohl(chunk.seq_num)+1);
            chunkACK.selective_acks = 0;
            sendto(sockfd, (struct ack_pkt_t *)&chunkACK, sizeof(chunkACK),0, (const struct sockaddr *) &cliaddr, len);
            str[ntohl(chunk.seq_num)-1] = chunk.data;
            //strcat(text,str[ntohl(chunk.seq_num)-1]);
            count++; 
            if (strlen(chunk.data)< MAX_DATA_SIZE)
            {
                fim = 1;
                break;
            }
        }
        if (fim == 1)
            break;
    }

    for (int i = 0; i < count; i++)
    {
        strcat(text,str[i]);
    }
    printf("%s\n",text );
    return 0; 
} 
